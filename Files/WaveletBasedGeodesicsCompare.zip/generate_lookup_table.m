function generate_lookup_table()
% Generates the polar geodesic cost lookup table as defined in:
% A. Jorstad, D. Jacobs, A. Trouve. "A Fast Illumination and Deformation
% Insensitive Image Comparison Algorithm Using Wavelet-Based Geodesics." 
% European Conference on Computer Vision (ECCV), Oct. 2012.
%
% The resulting table stores the point costs to compare a pair of polar 
% wavelet coefficients from two images:  [r1,theta1] and [r2,theta2]
% (points with original wavelet coefficients [H1,V1] and [H2,V2]).
% The table has dimension n_rs x n_rs x n_ts, the discretization of the
% number of radius bins and number of delta-theta bins.
% Each table entry is the length of the curve that is the solution to the
% relevant boundary value problem.
%
% Contact:  anne.jorstad@epfl.ch
%
% Copyright (c) 2012, Anne Jorstad
% May be used for academic purposes


% define parameters
e0 = 10^-2;  % the primary parameter:  the epsilon in the denominator
n_rs = 41;   % the number of bins 
a = e0;  b = 1.5;  % min and max values (of wavelet coefficients)
% discretization is chosen to be logscale
p0 = log(a);  p1 = log(b);
d = (p1 - p0) / (n_rs-1);
rng_log = p0:d:p1;
r_rng = exp(rng_log);
t_eps = pi/40;  % 82 bins, but really only half of this as is symmetric
tdiff_rng = 0:t_eps:pi;
tdiff_rng(41) = tdiff_rng(41) - 10^-3;  % nudge theta=pi, as this produces 
                                        % numerical errors
n_ts = length(tdiff_rng);
costs_table = single(zeros(n_rs, n_rs, n_ts));
N = 10^4;
filename = 'WaveletBasedGeodesicsLookupTable.mat';

% Generate the [radius_1, radius_2, delta_theta] table of cost values
th1 = 0;
for r1_ind = 1:n_rs
    r1 = r_rng(r1_ind);
for r2_ind = 1:n_rs
    disp(r2_ind)
    r2 = r_rng(r2_ind);
parfor tdiff_ind = 1:n_ts
if ~(tdiff_ind == 1 && r1_ind == r2_ind)  % in this case cost is 0
    th2 = tdiff_rng(tdiff_ind);
    [rs, thetas, drs, dthetas] = solve_bvp_numerical_polar(r1, r2, th1, ...
                                                           th2, e0, N);
    cost = cost_fcn_direct_derivs_polar(rs, thetas, drs, dthetas, e0, N);
    costs_table(r1_ind, r2_ind, tdiff_ind) = single(cost);
end
end
end
save(filename, 'costs_table', 'r_rng', 'tdiff_rng', 'N', 'e0')
end

% Make the table symmetric:
% This only affects a small number of entries, and only moderately, these
% differences are a result of the numerical BVP solver
load(filename)
for t = 1:n_ts
for r1 = 1:n_rs
for r2 = r1+1:n_rs
    c1 = costs_table(r1,r2,t);
    c2 = costs_table(r2,r1,t);
    this_min = min(c1,c2);
    costs_table(r1,r2,t) = this_min;
    costs_table(r2,r1,t) = this_min;
end
end
end
save(filename, 'costs_table', 'r_rng', 'tdiff_rng', 'N', 'e0')


%%%%%%%%%%%%%%% Helper Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [rs, thetas, drs, dthetas] = solve_bvp_numerical_polar(r0, r1, ...
                                                           th0, th1, e0, N)
% calculate the numerical geodesic path by solveing the boundary value  
% problem connecting [r0,th0] to [r1,th1]

low = 0;  % this doesn't matter
high = 1;
init_n = 100;
t_init = linspace(low, high, init_n);
y_init = @(t)initial_guess_polar(t, r0, r1, th0, th1, N);

BCs_ode = @(ya,yb)BCs_ode_full(ya,yb, r0, r1, th0, th1);
ode_eps_polar_here = @(t,y)ode_eps_polar(t,y,e0);

soln_init = bvpinit(t_init, y_init);
sol = bvp4c(ode_eps_polar_here, BCs_ode, soln_init);  

t = linspace(low,high,N);
cdc = deval(sol,t);
rs = cdc(1,:);
thetas = cdc(3,:);
drs = cdc(2,:);
dthetas = cdc(4,:);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function cost = cost_fcn_direct_derivs_polar(rs, thetas, drs, dthetas, ...
                                                                 e0, ntime)
% thetas is unused
num = drs.^2 + rs.^2 .* dthetas.^2;
denom = rs.^2 + e0^2;
terms = num ./ denom;
cost = sum(terms(:)) / ntime;
cost = sqrt(cost);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function dy = ode_eps_polar(t,y,e0)
r = y(1);  dr = y(2);  dth = y(4);
%th = y(3), but is unused

Dm1 = (r^2+e0^2)^-1;
ddr = r*dth^2+r*dr^2*Dm1 - r^3*dth^2*Dm1;
ddth = 2*r^-1*dr*dth*(r^2*Dm1-1);
dy = [dr; ddr; dth; ddth];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function dy = ode_separated_polar(t,y)
r = y(1);  dr = y(2);  dth = y(4);  
%th = y(3), but is unused

ddr = dr^2 / r;  % ddr = 1.5 * dr^2 / r; 
ddth = 0;
dy = [dr; ddr; dth; ddth];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function res = BCs_ode_full(ya,yb,c0_0,c0_1,c1_0,c1_1)
% for bvp4c
res = [ya(1) - c0_0;  yb(1) - c0_1;  ya(3) - c1_0;  yb(3) - c1_1];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function rdrtdt = initial_guess_polar(t, r0, r1, th0, th1, N)
r_here = (1-t)*r0 + t*r1;
th_here = (1-t)*th0 + t*th1;
dt = 1/(N-1);
r2 = (1-t-dt)*r0 + (t+dt)*r1;
t2 = (1-t-dt)*th0 + (t+dt)*th1;
dr = (r2 - r_here) * N;
dth = (t2 - th_here) * N;
rdrtdt = [r_here dr th_here dth];


